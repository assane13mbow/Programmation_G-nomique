"""BCM2550 - transcription example"""


import sys


def main():
    """BCM2550 - transcription example"""
    valid_nucleotides = set("ACGT")

    sequence = input("Please, enter a DNA sequence: ").upper()
    rna_seq = ""

    for nuc in sequence:
        if nuc not in valid_nucleotides:
            print(nuc, "is not a valid nucleotide...")
            sys.exit(1)

        # Dans l'ARN, le T est transforme en U
        if nuc == "T":
            nuc = "U"

        rna_seq = rna_seq + nuc

    print(rna_seq)


main()
