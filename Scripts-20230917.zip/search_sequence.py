"""BCM2550 - sequence search example"""


import sys


def main():
    """BCM2550 - sequence search example"""
    sequence = input("Please, enter a sequence: ").upper()
    pattern = input("Please, enter a search pattern: ").upper()

    if pattern not in sequence:
        print("Pattern not found")
        sys.exit(1)

    pattern_position = sequence.index(pattern)
    print(sequence)
    print((" " * pattern_position) + ("|" * len(pattern)))
    print((" " * pattern_position) + pattern)


main()
